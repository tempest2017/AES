/*
 * Advanced Encryption Standard
 * @author Dani Huertas
 * @email huertas.dani@gmail.com
 *
 * Based on the document FIPS PUB 197
 */
#include <stdio.h>
#include <stdlib.h>

#include "aes.h"

int main(int argc, char *argv[]) {

	uint8_t i;

	/*
	 * Appendix A - Key Expansion Examples
	 */
	 
	/* 128 bits */
	/* uint8_t key[] = {
		0x2b, 0x7e, 0x15, 0x16,
		0x28, 0xae, 0xd2, 0xa6,
		0xab, 0xf7, 0x15, 0x88,
		0x09, 0xcf, 0x4f, 0x3c}; */
	
	/* 192 bits */
	/* uint8_t key[] = {
		0x8e, 0x73, 0xb0, 0xf7,
		0xda, 0x0e, 0x64, 0x52,
		0xc8, 0x10, 0xf3, 0x2b,
		0x80, 0x90, 0x79, 0xe5,
		0x62, 0xf8, 0xea, 0xd2,
		0x52, 0x2c, 0x6b, 0x7b}; */
	
	/* 256 bits */
	/* uint8_t key[] = {
		0x60, 0x3d, 0xeb, 0x10,
		0x15, 0xca, 0x71, 0xbe,
		0x2b, 0x73, 0xae, 0xf0,
		0x85, 0x7d, 0x77, 0x81,
		0x1f, 0x35, 0x2c, 0x07,
		0x3b, 0x61, 0x08, 0xd7,
		0x2d, 0x98, 0x10, 0xa3,
		0x09, 0x14, 0xdf, 0xf4};
	*/
	
	/* uint8_t in[] = {
		0x32, 0x43, 0xf6, 0xa8,
		0x88, 0x5a, 0x30, 0x8d,
		0x31, 0x31, 0x98, 0xa2,
		0xe0, 0x37, 0x07, 0x34}; // 128
	*/

	/*
	 * Appendix C - Example Vectors
	 */

	/* 128 bit key */
	/* uint8_t key[] = {
		0x00, 0x01, 0x02, 0x03, 
		0x04, 0x05, 0x06, 0x07, 
		0x08, 0x09, 0x0a, 0x0b, 
		0x0c, 0x0d, 0x0e, 0x0f}; */
	
	/* 192 bit key */
	/* uint8_t key[] = {
		0x00, 0x01, 0x02, 0x03,
		0x04, 0x05, 0x06, 0x07,
		0x08, 0x09, 0x0a, 0x0b,
		0x0c, 0x0d, 0x0e, 0x0f,
		0x10, 0x11, 0x12, 0x13,
		0x14, 0x15, 0x16, 0x17}; */
	
	/* 256 bit key */
	uint8_t key[] = {
		0x00, 0x01, 0x02, 0x03,
		0x04, 0x05, 0x06, 0x07,
		0x08, 0x09, 0x0a, 0x0b,
		0x0c, 0x0d, 0x0e, 0x0f,
		0x10, 0x11, 0x12, 0x13,
		0x14, 0x15, 0x16, 0x17,
		0x18, 0x19, 0x1a, 0x1b,
		0x1c, 0x1d, 0x1e, 0x1f};
	/*
	uint8_t in[] = {
		0x00, 0x11, 0x22, 0x33,
		0x44, 0x55, 0x66, 0x77,
		0x88, 0x99, 0xaa, 0xbb,
		0xcc, 0xdd, 0xee, 0xff};
	*/
	//uint8_t out[16]; // 128

	uint8_t *w; // expanded key

	w = aes_init(sizeof(key));

	aes_key_expansion(key, w);

	char *source_path;
	FILE *file0 = fopen("C:\\Users\\Public\\notepad.exe", "rb");
	fseek(file0, 0, SEEK_END); 
	int len = ftell(file0); 
	rewind(file0);

	int size = len;
	if (len % 16 != 0) {
		size = (len / 16 + 1) * 16;
	}

	unsigned char *in = (char*)malloc(size*sizeof(char));
	fread(in, 1, len, file0);
	for (int j = len; j < size; ++j) {
		in[j] = '\0';
	}
	fclose(file0);

	printf("Plaintext message from file0:\n");
	for (i = 0; i < size / 4; i++) {
		printf("%#x %#x %#x %#x ", in[4 * i + 0], in[4 * i + 1], in[4 * i + 2], in[4 * i + 3]);
	}
	printf("\n");
	unsigned char *out = (char*)malloc(size*sizeof(char));
	//aes_cipher(in, out, w);
	
	for (int k = 0;k < size / 16 ;k++)
	{
		aes_cipher(&in[16 * k], &out[16 * k], w);
	}
	/*
	printf("Ciphered message:\n");
	for (i = 0; i <size / 4; i++) {
		printf("%#x %#x %#x %#x ", out[4 * i + 0], out[4 * i + 1], out[4 * i + 2], out[4 * i + 3]);
	}
	printf("\n");
	
	unsigned char *in1 = (char*)malloc(size*sizeof(char));
	//aes_inv_cipher(out, in1, w);
	for (int k = 0;k < size / 16;k++)
	{
		aes_inv_cipher(&out[16*k], &in1[16 * k], w);
	}
	printf("Plaintext message from Ciphered:\n");
	for (i = 0; i <size / 4; i++) {
		printf("%#x %#x %#x %#x ", in1[4 * i + 0], in1[4 * i + 1], in1[4 * i + 2], in1[4 * i + 3]);
	}
	printf("\n");
	*/
	FILE *file1 = fopen("C:\\Users\\Public\\notepad1.exe", "wb");
	fwrite(out, size, 1, file1);
	fflush(file1);
	fclose(file1);
	/////////////////////////////////////////////////////////////////////////////////////////////
	FILE *file2 = fopen("c:\\users\\public\\notepad2.exe", "rb");
	fseek(file0, 0, SEEK_END);
	int lenoffile2 = ftell(file2);
	if (lenoffile2 % 16 != 0)
	{
		return -1;
	}
	rewind(file2);
	unsigned char *out2 = (char*)malloc(lenoffile2*sizeof(char));
	fread(out2, 1, lenoffile2, file2);
	fclose(file2);
	if (strcmp(out, out2) != 0)
	{
		printf("out!=out2\n");
	}
	/*
	printf("Ciphered message from file2:\n");
	for (i = 0; i <lenoffile2 / 4; i++) {
		printf("%#x %#x %#x %#x ", out2[4 * i + 0], out2[4 * i + 1], out2[4 * i + 2], out2[4 * i + 3]);
	}
	printf("\n");
	*/
	unsigned char *content2 = (char*)malloc((lenoffile2)*sizeof(char));
	for (int k = 0;k < lenoffile2 / 16;k++)
	{
		aes_inv_cipher(&out2[16 * k], &content2[16 * k], w);
	}

	printf("Plaintext message from file2:\n");
	for (i = 0; i <lenoffile2 / 4; i++) {
		printf("%#x %#x %#x %#x ", content2[4 * i + 0], content2[4 * i + 1], content2[4 * i + 2], content2[4 * i + 3]);
	}
	printf("\n");

	int length;
	for (int k = 0;k <lenoffile2 / 16;k++)
	{
		for (i = 0;i < 16;i++)
		{
			if (content2[k * 16 + i] == '\0')
			{
				length = k * 16 + i;
				break;
			}
		}
	}

	FILE *file3 = fopen("C:\\Users\\Public\\3.txt", "w");
	fwrite(content2, length, 1, file3);
	fflush(file3);
	fclose(file3);

	free(w);
	free(in);
	free(out);
	free(out2);
	free(content2);
	exit(0);
}
